# ACMI Starter Kit v1

**The Fleet Coordination Protocol for AI Builders.**
MIT protocol · paid fleet recipe · 10 production agents · Redis schema · governance dashboard · Claude Code / Cursor / Cline-ready.

You bought this kit. Here's how to go from zero to your first agent logging to a shared timeline in **15 minutes**.

> **What you're buying is not the protocol** (that's MIT, free on GitHub).
> You're buying ~10 hours of fleet wiring already done — the agent configurations, the dashboard, the cron templates, the deploy guide, and 90 days of Discord access.

---

## Prerequisites (5 min)

1. **An Upstash Redis instance.** Free tier works for testing.
   → Sign up at https://upstash.com → "Create Database" → Region: closest to you → Type: Regional → Eviction: noeviction (so events don't drop).
   → Copy the **REST URL** and **REST Token** from the database's "REST API" tab.

2. **Node 22+** installed locally.
   ```bash
   node --version  # should be >= 22
   ```

3. **An MCP-capable agent host:** Claude Code (recommended), Cursor, Cline, Claude Desktop, Cowork — any of those work.

4. **(Optional) Anthropic API key** if you'll use the included Lobster Trap LLM governance policy locally.

That's it. No vector DB. No GPU. No additional services.

---

## Step 1 — Install the npm package (1 min)

```bash
npm install @madezmedia/acmi
```

Verify:
```bash
node -e "import('@madezmedia/acmi').then(m=>console.log(Object.keys(m)))"
```
You should see `connect`, `profile`, `signal`, `event`, `work`, etc.

---

## Step 2 — Install the MCP server (3 min)

The ACMI MCP server exposes 17 tools to your agent host. Two paths:

### Via Smithery (one-click, recommended)

1. Visit https://smithery.ai/server/@madezmediapartners/acmi-mcp
2. Click "Install" for your host (Claude Desktop, Claude Code, Cursor, Cline)
3. Smithery walks you through pasting your Upstash credentials. **Your creds never leave your machine.**

### Via local config (manual)

Add to your MCP host's config (e.g. `~/Library/Application Support/Claude/claude_desktop_config.json` for Claude Desktop):

```json
{
  "mcpServers": {
    "acmi": {
      "command": "npx",
      "args": ["-y", "@madezmedia/acmi-mcp"],
      "env": {
        "UPSTASH_REDIS_REST_URL": "https://your-upstash-url.upstash.io",
        "UPSTASH_REDIS_REST_TOKEN": "your-token-here"
      }
    }
  }
}
```

Restart your host. You should now see 17 ACMI tools available (`acmi_profile`, `acmi_event`, `acmi_search_semantic`, etc.).

---

## Step 3 — Set up your first agent (2 min)

Pick one of the 10 agent profiles in `02-agents/` that matches what you're building. For most people that's `claude-engineer.profile.json` (your daily coding agent).

In your agent host, ask:
> "Use the acmi_profile tool to register me as agent claude-engineer with the profile from the starter kit."

Or do it manually via the MCP tool call. The agent host should respond with a confirmation event.

---

## Step 4 — Log your first event (1 min)

```
Use acmi_event to log this:
  namespace: agent
  id: claude-engineer
  kind: heartbeat
  summary: "[heartbeat] first wake from starter kit"
```

That's it. Your agent is now on the timeline.

---

## Step 5 — View the timeline (1 min)

```
Use acmi_cat to read the last 10 events from acmi:agent:claude-engineer:timeline
```

You should see your heartbeat. **Welcome to ACMI.**

---

## Step 6 — Run multiple agents (2 min)

Open a second host (Cursor, Cline, whatever). Configure with the *same* Upstash creds. Use the `bentley.profile.json` profile (the orchestrator).

Now ask the second agent:
> "Use acmi_cat to read acmi:agent:claude-engineer:timeline"

It sees the first agent's events. **Your fleet is coordinating.** They're not the same agent. They didn't share context. They share a timeline.

This is the wedge. This is why ACMI exists.

---

## What's in the rest of the kit

| Folder | Contents |
|---|---|
| `01-protocol-spec/` | ACMI Protocol v1.3 — the full 40-page ratified spec |
| `02-agents/` | 10 production agent profiles + signals + system prompts |
| `03-redis-schema/` | Keyspace layout, ZADD patterns, `bootstrap.sh` one-command setup |
| `04-crons/` | 31 openclaw cron jobs + 8 launchd .plist templates from production |
| `05-lobstertrap/` | Veea-integrated LLM-boundary governance policy template |
| `06-dashboard/` | Forkable React governance dashboard (source for acmi-product.vercel.app/governance-dashboard.html) |
| `07-mcp/` | @madezmedia/acmi-mcp install + custom-tool patterns |
| `08-discord-invite/` | Your Discord invite + first-90-day support channel access |

---

## Roadmap

**v1.0 (you have this now)** — protocol + 10 agents + dashboard + crons + Discord access. Stub-out: some folders may have a single README pointing at the live source-of-truth repo (`github.com/madezmedia/acmi-product`). **Full ZIP bundle lands within 48h of your purchase.** You'll get an email when it does.

**v1.x updates** — included free with your purchase. The protocol evolves; the kit evolves with it.

**Upgrade path** — when you outgrow the kit, the [Claude Engineer Lab](https://whop.com/madezmedia/claude-engineer-lab) is $39/mo and includes weekly live builds + skill drops + lifetime Discord.

---

## Need help?

- **Discord:** `#starter-kit-help` — invite in `08-discord-invite/INVITE.md`. 90-day access.
- **Email:** madezmediapartners@gmail.com — for billing/refund/partnership questions.
- **GitHub:** github.com/madezmedia/acmi-product — public repo, issues welcome.
- **Live dashboard:** acmi-product.vercel.app/governance-dashboard.html — proof the protocol works at scale.

If you got stuck before your first heartbeat landed, DM me in Discord with what step you got to. I read every one.

— Mikey
Mad EZ Media · @madezmedia
