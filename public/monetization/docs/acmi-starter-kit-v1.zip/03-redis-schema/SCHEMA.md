ACMI Redis Schema v1.3
